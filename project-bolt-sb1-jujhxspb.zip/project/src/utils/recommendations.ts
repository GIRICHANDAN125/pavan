import { Product, UserPreference } from '../types';

export const getSimilarProducts = (product: Product, allProducts: Product[]): Product[] => {
  return allProducts
    .filter(p => p.id !== product.id && p.category === product.category)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);
};

export const getTrendingProducts = (products: Product[]): Product[] => {
  return [...products]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);
};

export const getPersonalizedRecommendations = (
  products: Product[],
  preferences: UserPreference[]
): Product[] => {
  const scoreProduct = (product: Product): number => {
    const categoryPreference = preferences.find(p => p.category === product.category);
    const preferenceWeight = categoryPreference ? categoryPreference.weight : 1;
    return product.rating * preferenceWeight;
  };

  return [...products]
    .sort((a, b) => scoreProduct(b) - scoreProduct(a))
    .slice(0, 3);
};