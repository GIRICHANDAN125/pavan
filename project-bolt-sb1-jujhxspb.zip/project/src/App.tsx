import React, { useState } from 'react';
import { ShoppingBag } from 'lucide-react';
import { products } from './data/products';
import { RecommendationSection } from './components/RecommendationSection';
import { UserPreference } from './types';
import {
  getSimilarProducts,
  getTrendingProducts,
  getPersonalizedRecommendations,
} from './utils/recommendations';

function App() {
  const [selectedProduct] = useState(products[0]);
  
  // Simulated user preferences - in a real app, this would come from user data
  const userPreferences: UserPreference[] = [
    { category: 'electronics', weight: 1.5 },
    { category: 'clothing', weight: 1.2 },
  ];

  const similarProducts = getSimilarProducts(selectedProduct, products);
  const trendingProducts = getTrendingProducts(products);
  const personalizedProducts = getPersonalizedRecommendations(products, userPreferences);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <ShoppingBag className="h-8 w-8 text-blue-600" />
            <h1 className="ml-2 text-2xl font-bold text-gray-900">ShopSmart</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-12">
          <RecommendationSection
            type="similar"
            products={similarProducts}
            title="Similar Products"
          />
          
          <RecommendationSection
            type="trending"
            products={trendingProducts}
            title="Trending Now"
          />
          
          <RecommendationSection
            type="based-on-history"
            products={personalizedProducts}
            title="Recommended for You"
          />
        </div>
      </main>
    </div>
  );
}

export default App;