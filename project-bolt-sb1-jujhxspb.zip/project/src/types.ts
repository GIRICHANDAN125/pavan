export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
}

export interface UserPreference {
  category: string;
  weight: number;
}

export type RecommendationType = 'similar' | 'trending' | 'based-on-history';